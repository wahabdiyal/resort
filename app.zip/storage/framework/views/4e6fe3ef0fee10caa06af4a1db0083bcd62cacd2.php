<div class="top_menu transparent hidden-xs">
    <div class="container">
        <ul class="top_menu_right">
            <li><i class="fa  fa-phone"></i><a href="tel:18475555555"> 1-888-123-4567 </a></li>
            <li class="email"><i class="fa  fa-envelope-o "></i> <a href="mailto:contact@site.com">contact@site.com</a></li>
            <li class="language-switcher">

            </li>
        </ul>
    </div>
</div>

<header class="fixed transparent">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle mobile_menu_btn" data-toggle="collapse" data-target=".mobile_menu" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
            <a class="navbar-brand light" href="index.html">
                <img src="https://pp.limited/images/logo.png" height="32" alt="Logo">
            </a>
            <a class="navbar-brand dark nodisplay" href="index.html">
                <img src="https://pp.limited/images/logo.png" height="32" alt="Logo">
            </a>
        </div>
        <nav id="main_menu" class="mobile_menu navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="mobile_menu_title" style="display:none;">MENU</li>
                <li class="dropdown simple_menu active">
                    <a href="#" >HOME </a>

                </li>

                <li><a href="contact.html">CONTACT US</a></li>

                <li class="menu_button">
                    <a href="booking-form.html" class="button  btn_yellow"><i class="fa fa-calendar"></i>BOOK ONLINE</a>
                </li>
            </ul>
        </nav>
    </div>
</header>
<?php /**PATH C:\laragon\www\event\resources\views/main/include/nav.blade.php ENDPATH**/ ?>